# This is the most basic python code you can think of
# Python files have the extension .py.
# Comments are written using #
# Very easy to get into. For example, here is a very simple code:

print("Hello World!")